import bpy
import numpy as np
import sys
from addon_utils import check, paths, enable


############################################################################################################

MR_list = [
        "spine.006",
        "spine.005",
        "shoulder.L",
        "shoulder.R",
        "breast.L",
        "breast.R",
        "spine.003",
        "spine.002",
        "spine.001",
        "spine",
        "thigh.L",
        "shin.L",
        "foot.L",
        "toe.L",
        "thigh.R",
        "shin.R",
        "foot.R",
        "toe.R",
        "upper_arm.L",
        "forearm.L",
        "hand.L",
        "upper_arm.R",
        "forearm.R",
        "hand.R"
        ]

MR_face = ['face', 'nose', 'nose.001', 'nose.002',
       'nose.003', 'nose.004', 'lip.T.L', 'lip.T.L.001', 'lip.B.L',
       'lip.B.L.001', 'jaw', 'chin', 'chin.001', 'ear.L', 'ear.L.001',
       'ear.L.002', 'ear.L.003', 'ear.L.004', 'ear.R', 'ear.R.001',
       'ear.R.002', 'ear.R.003', 'ear.R.004', 'lip.T.R', 'lip.T.R.001',
       'lip.B.R', 'lip.B.R.001', 'brow.B.L', 'brow.B.L.001',
       'brow.B.L.002', 'brow.B.L.003', 'lid.T.L', 'lid.T.L.001',
       'lid.T.L.002', 'lid.T.L.003', 'lid.B.L', 'lid.B.L.001',
       'lid.B.L.002', 'lid.B.L.003', 'brow.B.R', 'brow.B.R.001',
       'brow.B.R.002', 'brow.B.R.003', 'lid.T.R', 'lid.T.R.001',
       'lid.T.R.002', 'lid.T.R.003', 'lid.B.R', 'lid.B.R.001',
       'lid.B.R.002', 'lid.B.R.003', 'forehead.L', 'forehead.L.001',
       'forehead.L.002', 'temple.L', 'jaw.L', 'jaw.L.001', 'chin.L',
       'cheek.B.L', 'cheek.B.L.001', 'brow.T.L', 'brow.T.L.001',
       'brow.T.L.002', 'brow.T.L.003', 'forehead.R', 'forehead.R.001',
       'forehead.R.002', 'temple.R', 'jaw.R', 'jaw.R.001', 'chin.R',
       'cheek.B.R', 'cheek.B.R.001', 'brow.T.R', 'brow.T.R.001',
       'brow.T.R.002', 'brow.T.R.003', 'eye.L', 'eye.R', 'cheek.T.L',
       'cheek.T.L.001', 'nose.L', 'nose.L.001', 'cheek.T.R',
       'cheek.T.R.001', 'nose.R', 'nose.R.001', 'teeth.T', 'teeth.B',
       'tongue', 'tongue.001', 'tongue.002']

#left hand
thumb_L = ["thumb.01.L", "thumb.02.L", "thumb.03.L"]
index_L = ["palm.01.L", "f_index.01.L", "f_index.02.L", "f_index.03.L"]
middle_L = ["palm.02.L", "f_middle.01.L", "f_middle.02.L", "f_middle.03.L"]
ring_L = ["palm.03.L", "f_ring.01.L", "f_ring.02.L", "f_ring.03.L"]
pinky_L = ["palm.04.L", "f_pinky.01.L", "f_pinky.02.L", "f_pinky.03.L"]
#right hand
thumb_R = ["thumb.01.R", "thumb.02.R", "thumb.03.R"]
index_R = ["palm.01.R", "f_index.01.R", "f_index.02.R", "f_index.03.R"]
middle_R = ["palm.02.R", "f_middle.01.R", "f_middle.02.R", "f_middle.03.R"]
ring_R = ["palm.03.R", "f_ring.01.R", "f_ring.02.R", "f_ring.03.R"]
pinky_R = ["palm.04.R", "f_pinky.01.R", "f_pinky.02.R", "f_pinky.03.R"]

MR_fingers = thumb_L + index_L + middle_L + ring_L + pinky_L + thumb_R + index_R + middle_R + ring_R + pinky_R

############################################################################################################

MB_list = [
        "head",
        "neck",
        "clavicle_L",
        "clavicle_R",
        "breast_L",
        "breast_R",
        "spine03",
        "spine02",
        "spine01",
        "pelvis",
        "thigh_L",
        "calf_L",
        "foot_L",
        "toes_L",
        "thigh_R",
        "calf_R",
        "foot_R",
        "toes_R",
        "upperarm_L",
        "lowerarm_L",
        "hand_L",
        "upperarm_R",
        "lowerarm_R",
        "hand_R"
        ]

#left hand
thumb_l = ["thumb01_L", "thumb02_L", "thumb03_L"]
index_l = ["index00_L", "index01_L", "index02_L", "index03_L"]
middle_l = ["middle00_L", "middle01_L", "middle02_L", "middle03_L"]
ring_l = ["ring00_L", "ring01_L", "ring02_L", "ring03_L"]
pinky_l = ["pinky00_L", "pinky01_L", "pinky02_L", "pinky03_L"]
#right hand
thumb_r = ["thumb01_R", "thumb02_R", "thumb03_R"]
index_r = ["index00_R", "index01_R", "index02_R", "index03_R"]
middle_r = ["middle00_R", "middle01_R", "middle02_R", "middle03_R"]
ring_r = ["ring00_R", "ring01_R", "ring02_R", "ring03_R"]
pinky_r = ["pinky00_R", "pinky01_R", "pinky02_R", "pinky03_R"]

MB_fingers = thumb_l + index_l + middle_l + ring_l + pinky_l + thumb_r + index_r + middle_r + ring_r + pinky_r

############################################################################################################

MBx = ["pelvis", "pelvis", "upperarm_twist_L", "upperarm_twist_R", "lowerarm_twist_L", "lowerarm_twist_R", "thigh_twist_L", "thigh_twist_R", "calf_twist_L", "calf_twist_R", "neck"]
MRx = ["pelvis.L", "pelvis.R", "upper_arm.L.001", "upper_arm.R.001", "forearm.L.001", "forearm.R.001", "thigh.L.001", "thigh.R.001", "shin.L.001", "shin.R.001", "spine.004"]

MB_parts = MB_list + MB_fingers + MBx
MR_parts = MR_list + MR_fingers + MRx

############################################################################################################

spine = ["tweak_spine", "tweak_spine.001", "tweak_spine.002", "tweak_spine.003", "tweak_spine.004", "tweak_spine.005",]
torso = ["hips", "chest", "neck", "head"]
fk_arms = ["upper_arm_fk.L", "forearm_fk.L", "upper_arm_fk.R", "forearm_fk.R"]
fk_legs = ["thigh_fk.L", "shin_fk.L", "thigh_fk.R", "shin_fk.R"]

############################################################################################################



rig_bones = [3,5,28]
tweak_bones = [4,6,9,12,15,18]
ik_bones = [7,10,13,16]
fk_bones = [8,11,14,17]

def ragdoll_dict(part_names):
    rd = {
        part_names[0]: [-25, 45, -45, 45, -30, 30, part_names[1], .06],             #head  #x -22, 37,
        part_names[1]: [-25, 45, -45, 45, -30, 30, part_names[18], .02],            #neck  #x -22, 37,
        part_names[2]: [-30, 30, 0, 0, -30, 10, part_names[1], .05],                #clavicle_L
        part_names[3]: [-30, 30, 0, 0, -10, 30, part_names[1], .05],                #clavicle_R
        part_names[20]: [-10, 10, 0, 0, 0, 0, part_names[18], .05],                 #breast_L
        part_names[21]: [-10, 10, 0, 0, 0, 0, part_names[18], .05],                 #breast_R
        part_names[19]: [-22, 45, -45, 45, -15, 15, '', .1],                        #pelvis
        part_names[16]: [-55, 68, -45, 45, -30, 30, part_names[19], .1],            #spine_01
        part_names[17]: [-45, 45, -45, 45, -30, 30, part_names[16], .2],            #spine_02
        part_names[18]: [-45, 45, -45, 45, -30, 30, part_names[17], .1],            #spine_03
        part_names[4]: [-58, 95, -30, 15, -60, 105, part_names[2], .03],            #upperarm_L
        part_names[5]: [-58, 95, -30, 15, -60, 105, part_names[3], .03],            #upperarm_R
        part_names[6]: [-146, 0, -15, 0, 0, 0, part_names[4], .014],                #lowerarm_L
        part_names[7]: [-146, 0, -15, 0, 0, 0, part_names[5], .014],                #lowerarm_R
        part_names[8]: [-30, 30, -15, 15, -25, 36, part_names[6], .006],            #hand_L
        part_names[9]: [-30, 30, -15, 15, -36, 25, part_names[7], .006],            #hand_R
        part_names[10]: [-90, 45, -15, 15, -22, 17, part_names[19], .1],            #thigh_L
        part_names[11]: [-90, 45, -15, 15, -22, 17, part_names[19], .1],            #thigh_R
        part_names[12]: [0, 150, 0, 0, -3, 3, part_names[10], .05],                 #calf_L
        part_names[13]: [0, 150, 0, 0, -3, 3, part_names[11], .05],                 #calf_R
        part_names[14]: [-44, 45, -26, 26, -15, 74, part_names[12], .01],           #foot_L
        part_names[15]: [-45, 44, -26, 26, -74, 15, part_names[13], .01],           #foot_R
        }
    return rd

############################################################################################################

def timeit(method):
    import time
    def timed(*args, **kw):
        ts = time.time()
        result = method(*args, **kw)
        te = time.time()
        if 'log_time' in kw:
            name = kw.get('log_name', method.__name__.upper())
            kw['log_time'][name] = int((ts - te) * 1000)
        else:
            print("{}, {} milliseconds".format(method.__name__, ((te - ts) * 1000)))
        return result
    return timed

def get_os():
    import platform
    gos = platform.system()
    if gos == 'Windows':
        return 'win'
    if gos == 'Darwin':
        return 'mac'
    else:
        return 'linux'

def get_addons():
    paths_list = paths()
    addon_list = []
    for path in paths_list:
        for modName, modPath in bpy.path.module_names(path):
            is_enabled, is_loaded = check(modName)
            addon_list.append(modName)
    return(addon_list)

def enable_addon(dependencies):
    addons = get_addons()
    for addon in dependencies:
        is_enabled, is_loaded = check(addon)
        if not is_enabled:
            enable(addon, default_set=True)
        else:
            if addon in addons:
                print("Error {} is Already Enabled".format(addon))
            else:
                print("Error {} is Missing ".format(addon))

def collection_object_list(collection):
    return [o.name for o in bpy.data.collections[collection].objects[:]]

def new_collection(Name):
    new_coll = bpy.data.collections.new(Name)
    bpy.context.scene.collection.children.link(new_coll)
    return new_coll

def active_ob(object, objects):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.data.objects[object].select_set(state=True)
    bpy.context.view_layer.objects.active = bpy.data.objects[object]
    if objects is not None:
        for o in objects:
            bpy.data.objects[o].select_set(state=True)

@timeit
def bone_collector(armature, Dict=True):
    bones = bpy.data.armatures[armature].bones
    count = len(bones)
    bc = np.empty((count, 2))
    bn = np.empty(count, dtype='U10')
    bhd = np.empty((count * 3), dtype=float).round(decimals=5)
    bhr = np.empty(count, dtype=float).round(decimals=5)
    btl = np.empty((count * 3), dtype=float).round(decimals=5)
    btr = np.empty(count, dtype=float).round(decimals=5)
    bl = np.empty(count, dtype=float).round(decimals=5)
    bn = np.asarray([i.name for i in bones])
    bones.foreach_get('head_local', bhd)
    bones.foreach_get('head_radius', bhr)
    bones.foreach_get('tail_local', btl)
    bones.foreach_get('tail_radius', btr)
    bones.foreach_get('length', bl)
    bhd.shape = ((count, 3))
    btl.shape = ((count, 3))
    bc = list(zip(bn, np.array(list(zip(bhd, btl, bhr, btr, bl)))))
    if Dict == False:
        return np.array(bc)
    else:
        return dict(bc)

#---------------------------------------------------------

@timeit
def show_rig(object, idx, Bool):
    for r in idx:
        object.data.layers[r] = Bool

#---------------------------------------------------------

@timeit
def limit_bone_distance(Bone, tar, mode):
    obj = bpy.data.objects
    bcrig = bone_collector(-1)
    dist = np.linalg.norm((bcrig[Bone] - bcrig[tar])).tolist()[0]
    pb1 = obj["rig"].pose.bones.get(Bone)
    pb2 = obj["rig"].pose.bones.get(tar)
    bc = pb1.constraints.new("LIMIT_DISTANCE")
    bc.owner_space = 'LOCAL'
    bc.target = obj["rig"]
    bc.subtarget = tar
    bc.limit_mode = mode
    bc.distance = dist
    bc.owner_space = 'POSE'
    bc.target_space = 'POSE'

@timeit
def limit_distance(Obj, tar, lm):
    obj = bpy.data.objects
    ob = obj[Obj]
    ld = ob.constraints.new("LIMIT_DISTANCE")
    ld.owner_space = 'LOCAL'
    ld.target = obj[tar]
    ld.limit_mode = lm

@timeit
def bone_copy_transform(Obj, Bone, tar):
    obj = bpy.data.objects
    pb = obj[Obj].pose.bones.get(Bone)
    bc = pb.constraints.new("COPY_TRANSFORMS")
    bc.target = obj[tar]

@timeit
def obj_copy_transform(Obj, tar):
    obj = bpy.data.objects
    ob = obj[Obj]
    ct = ob.constraints.new("COPY_TRANSFORMS")
    ct.target = obj[tar]

@timeit
def copy_transform(Obj, tar, sub, ht):
    obj = bpy.data.objects
    ob = obj[Obj]
    ct = ob.constraints.new("COPY_TRANSFORMS")
    ct.target = obj[tar]
    ct.subtarget = sub
    ct.target_space = 'POSE'
    ct.head_tail = ht

@timeit
def bone_copy_rot(Obj, Bone, tar, influence=1):
    obj = bpy.data.objects
    pb = obj[Obj].pose.bones.get(Bone)
    bc = pb.constraints.new("COPY_ROTATION")
    bc.target = obj[tar]
    bc.influence = influence

@timeit
def copy_loc(Obj, tar):
    obj = bpy.data.objects
    cl = obj[Obj].constraints.new("COPY_LOCATION")
    cl.target = obj[tar]

@timeit
def obj_limit_rot(Obj, limits, space):
    obj = bpy.data.objects
    lr = obj[Obj].constraints.new('LIMIT_ROTATION')
    lr.owner_space = space
    lr.use_limit_x = True
    lr.use_limit_y = True
    lr.use_limit_z = True
    lr.min_x = np.radians(limits[0])
    lr.max_x = np.radians(limits[1])
    lr.min_y = np.radians(limits[2])
    lr.max_y = np.radians(limits[3])
    lr.min_z = np.radians(limits[4])
    lr.max_z = np.radians(limits[5])

@timeit
def bone_limit_rot(Bone, limits, space):
    obj = bpy.data.objects
    pb = obj["rig"].pose.bones
    lr = pb[Bone].constraints.new('LIMIT_ROTATION')
    lr.owner_space = space
    lr.use_limit_x = True
    lr.use_limit_y = True
    lr.use_limit_z = True
    lr.min_x = np.radians(limits[0])
    lr.max_x = np.radians(limits[1])
    lr.min_y = np.radians(limits[2])
    lr.max_y = np.radians(limits[3])
    lr.min_z = np.radians(limits[4])
    lr.max_z = np.radians(limits[5])

@timeit
def bone_damp_trac(Bone, tar, track):
    obj = bpy.data.objects
    pb = obj["rig"].pose.bones
    dt = pb[Bone].constraints.new('DAMPED_TRACK')
    dt.target = obj[tar]
    dt.track_axis = track

@timeit
def damp_trac(Obj, tar):
    obj = bpy.data.objects
    dt = obj[Obj].constraints.new('DAMPED_TRACK')
    dt.target = obj[tar]

@timeit
def follow_path(object, tar):
    obj = bpy.data.objects
    fp = obj[object].constraints.new('FOLLOW_PATH')
    fp.target = obj[tar]
    fp.use_curve_radius = True

#---------------------------------------------------------


@timeit
def rig_influence(val, bones):
    obj = bpy.data.objects
    pb = obj["rig"].pose.bones
    for bone in bones:
        pb[bone]["IK_FK"] = val

@timeit
def CT_influence(val, bones):
    obj = bpy.data.objects
    pb = obj["rig"].pose.bones
    for bone in bones:
        pb[bone].constraints["Copy Transforms"].influence = val

#---------------------------------------------------------

@timeit
def obj_driver(Obj, path, idx, tar, trans, exp='var'):
    obj = bpy.data.objects
    dr = obj[Obj].driver_add(path, idx).driver
    dr.type = 'SCRIPTED'
    dr.expression = exp
    var = dr.variables.new()
    var.type = 'TRANSFORMS'
    var.targets[0].id = obj[tar]
    var.targets[0].transform_type = trans
    var.targets[0].transform_space = 'WORLD_SPACE'
    #var.targets[0].bone_target = bt

@timeit
def bone_driver(Bone, path, idx, tar, trans):
    obj = bpy.data.objects
    dr = obj["rig"].pose.bones[Bone].driver_add(path, idx).driver
    dr.type = 'SCRIPTED'
    dr.expression = 'var'
    var = dr.variables.new()
    var.type = 'TRANSFORMS'
    var.targets[0].id = obj[tar]
    var.targets[0].transform_type = trans
    var.targets[0].transform_space = 'WORLD_SPACE'

@timeit
def rename_vgroup(vg, newName):
    rem_vg = lambda g: vg.remove(vg.get(g))
    rem_vg("DEF-spine.004")
    for new, old in newName:
        o = vg.get(old)
        new = 'DEF-{}'.format(new)
        n = vg.get(new)
        if (o is None) or (n is None):
            continue
        rem_vg(new)
        if 'pelvis' in new:
            new = 'DEF-spine'
        o.name = new

#---------------------------------------------------------

@timeit
def align_rig(fingers=True):
    try:
        enable_addon(["rigify"])
    except:
        pass
    if fingers == True:
        bpy.ops.object.armature_human_metarig_add()
    else:
        bpy.ops.object.armature_basic_human_metarig_add()
    p_extra = ["pelvis.L", "pelvis.R"]
    bcmb = bone_collector(0)
    bcmr = bone_collector(-1)
    arm_MR = bpy.data.objects['metarig']
    spine = bcmr['spine']
    pelvis = bcmb['pelvis']
    pscale = (spine[4] / pelvis[4])
    if not arm_MR.data.is_editmode:
        bpy.ops.object.editmode_toggle()
    for i in list(zip(MR_list, MB_list)):
        MR = i[0]
        MB = i[1]
        arm_MR.data.edit_bones[MR].head = bcmb[MB][0]
        arm_MR.data.edit_bones[MR].tail = bcmb[MB][1]
        arm_MR.data.edit_bones[MR].head_radius = bcmb[MB][2]
        arm_MR.data.edit_bones[MR].tail_radius = bcmb[MB][3]
    for p in p_extra:
        vec = bcmr[p][1] - bcmr[p][0]
        arm_MR.data.edit_bones[p].head = pelvis[0]
        arm_MR.data.edit_bones[p].tail = pelvis[0] + (vec * pscale)
        arm_MR.data.edit_bones[p].head_radius = pelvis[2]
        arm_MR.data.edit_bones[p].tail_radius = pelvis[3]
    arm_MR.data.edit_bones['spine.004'].head = bcmb['spine03'][1]
    arm_MR.data.edit_bones['spine.004'].tail = bcmb['neck'][0]
    arm_MR.data.edit_bones[p_extra[0]].tail.x = bcmb['thigh_L'][0][0]
    arm_MR.data.edit_bones[p_extra[0]].tail.y = bcmb['thigh_L'][0][1]
    arm_MR.data.edit_bones[p_extra[1]].tail.x = bcmb['thigh_R'][0][0]
    arm_MR.data.edit_bones[p_extra[1]].tail.y = bcmb['thigh_R'][0][1]
    hdL = bcmr["heel.02.L"][0] + (bcmb["foot_L"][0] - bcmr["foot.L"][0])
    hdL[2] = 0.0
    tlL = hdL + np.array([bcmr["heel.02.L"][4], 0, 0])
    hdR = bcmr["heel.02.R"][0] + (bcmb["foot_R"][0] - bcmr["foot.R"][0])
    hdR[2] = 0.0
    tlR = hdR + np.array([-bcmr["heel.02.R"][4], 0, 0])
    arm_MR.data.edit_bones["heel.02.L"].head = hdL
    arm_MR.data.edit_bones["heel.02.L"].tail = tlL
    arm_MR.data.edit_bones["heel.02.R"].head = hdR
    arm_MR.data.edit_bones["heel.02.R"].tail = tlR
    if fingers == True:
        bpy.ops.armature.select_all(action='DESELECT')
        for bo in MR_face:
            arm_MR.data.edit_bones[bo].select = True
        bpy.ops.armature.delete()
        bpy.ops.armature.select_all(action='DESELECT')
        for i in list(zip(MR_fingers, MB_fingers)):
            MR = i[0]
            MB = i[1]
            arm_MR.data.edit_bones[MR].head = bcmb[MB][0]
            arm_MR.data.edit_bones[MR].tail = bcmb[MB][1]
            arm_MR.data.edit_bones[MR].head_radius = bcmb[MB][2]
            arm_MR.data.edit_bones[MR].tail_radius = bcmb[MB][3]
    if arm_MR.data.is_editmode:
        bpy.ops.object.editmode_toggle()

@timeit
def parent_rig():
    arm_MB = bpy.data.objects[[i.name for i in bpy.data.objects if i.type == 'ARMATURE'][0]]
    body = arm_MB.children[0]
    arm_rig = bpy.data.objects['rig']
    arm_MR = bpy.data.objects['metarig']
    vg = body.vertex_groups
    comp = np.array(list(zip(MR_parts, MB_parts)))
    bpy.ops.object.select_all(action='DESELECT')
    active_ob(arm_rig.name, [body.name])
    bpy.ops.object.parent_set(type='ARMATURE_AUTO')
    rename_vgroup(vg, comp)
    arm_MB.hide_viewport = True
    arm_MR.hide_viewport = True
    arm_rig.show_in_front = True
    show_rig(arm_rig, (tweak_bones + fk_bones), False)
    bpy.ops.object.select_all(action='DESELECT')

@timeit
def pino_kio_rig():
    coll = bpy.context.collection
    pkcoll = new_collection("Pino_Kio_Rig")
    bcmb = bone_collector(0)
    bcrig = bone_collector(-1)
    pkrig = ["torso", "hand_ik.L", "hand_ik.R", "foot_ik.L", "foot_ik.R"]
    e_type = ['CUBE', 'SPHERE', 'SPHERE', 'CIRCLE', 'CIRCLE']
    obj = bpy.data.objects
    en = 'Empty'
    pb = obj['rig'].pose.bones
    add_emp = lambda t, rad, l, r: bpy.ops.object.empty_add(type=t, radius=rad, align='WORLD', location=l, rotation=r)
    edge_maker = lambda Name, co: obj_new(Name, co, [[0, 1, 2]], [], pkcoll.name)
    ld = lambda ob: limit_distance(ob, "torso", 'LIMITDIST_INSIDE')
    ct = lambda Bone: bone_copy_transform('rig', Bone, Bone)
    ctb = lambda ob, ht: copy_transform(ob, 'rig', ob, ht)
    cr = lambda Bone, tar, i: bone_copy_rot("rig", Bone, tar, i)
    for r in list(zip(e_type, pkrig)):
        if r[1] == "torso":
            rad = 0.15
        else:
            rad = 0.1
        if r[1] == pkrig[1]:
            rot = (0,0,np.radians(-90))
        elif r[1] == pkrig[2]:
            rot = (0,0,np.radians(90))
        else:
            rot = (0,0,0)
        add_emp(r[0], rad, bcrig[r[1]][0], rot)
        obj[en].name = r[1]
        pkcoll.objects.link(obj[r[1]])
        coll.objects.unlink(obj[r[1]])
    add_emp('SPHERE', 0.2, bcrig['chest'][0], (0, 0, 0))
    obj[en].name = "chest_control"
    pkcoll.objects.link(obj["chest_control"])
    coll.objects.unlink(obj["chest_control"])
    add_emp('SPHERE', 0.2, bcrig['torso'][0], (0, 0, 0))
    obj[en].name = "hip_control"
    pkcoll.objects.link(obj["hip_control"])
    coll.objects.unlink(obj["hip_control"])
    add_emp('SPHERE', 0.2, bcrig['head'][0], (np.radians(90), 0, 0))
    obj[en].name = "head_control"
    pkcoll.objects.link(obj["head_control"])
    coll.objects.unlink(obj["head_control"])
    add_emp('SPHERE', 0.05, bcrig['upper_arm_ik.L'][0], (0, 0, 0))
    obj[en].name = 'upper_arm_ik.L'
    pkcoll.objects.link(obj['upper_arm_ik.L'])
    coll.objects.unlink(obj['upper_arm_ik.L'])
    add_emp('SPHERE', 0.05, bcrig['upper_arm_ik.L'][0], (0, 0, 0))
    obj[en].name = 'upper_arm_ik.R'
    pkcoll.objects.link(obj['upper_arm_ik.R'])
    coll.objects.unlink(obj['upper_arm_ik.R'])
    add_emp('SPHERE', 0.05, bcrig['thigh_ik.L'][0], (0, 0, 0))
    obj[en].name = 'thigh_ik.L'
    pkcoll.objects.link(obj['thigh_ik.L'])
    coll.objects.unlink(obj['thigh_ik.L'])
    add_emp('SPHERE', 0.05, bcrig['thigh_ik.R'][0], (0, 0, 0))
    obj[en].name = 'thigh_ik.R'
    pkcoll.objects.link(obj['thigh_ik.R'])
    coll.objects.unlink(obj['thigh_ik.R'])
    #
    add_emp('SPHERE', 0.05, bcrig['upper_arm_ik.L'][0], (0, 0, 0))
    obj[en].name = 'shoulder_socket.L'
    pkcoll.objects.link(obj['shoulder_socket.L'])
    coll.objects.unlink(obj['shoulder_socket.L'])
    add_emp('SPHERE', 0.05, bcrig['upper_arm_ik.R'][0], (0, 0, 0))
    obj[en].name = 'shoulder_socket.R'
    pkcoll.objects.link(obj['shoulder_socket.R'])
    coll.objects.unlink(obj['shoulder_socket.R'])
    #
    active_ob("chest_control", ["head_control"])
    bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
    active_ob("torso", ["chest_control"])
    bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
    for pk in pkrig[3:]:
        ld(pk)
    limit_distance("hand_ik.L", 'upper_arm_ik.L', 'LIMITDIST_INSIDE')
    limit_distance("hand_ik.R", 'upper_arm_ik.R', 'LIMITDIST_INSIDE')
    limit_distance('shoulder_socket.L', 'chest_control', 'LIMITDIST_OUTSIDE')
    limit_distance('shoulder_socket.R', 'chest_control', 'LIMITDIST_OUTSIDE')
    #
    limit_bone_distance("hand_ik.L", "forearm_tweak.L.001", 'LIMITDIST_INSIDE')
    limit_bone_distance("forearm_tweak.L.001", "forearm_tweak.L", 'LIMITDIST_INSIDE')
    limit_bone_distance("forearm_tweak.L", "upper_arm_tweak.L.001", 'LIMITDIST_INSIDE')
    limit_bone_distance("upper_arm_tweak.L.001", "upper_arm_tweak.L", 'LIMITDIST_INSIDE')
    limit_bone_distance("hand_ik.R", "forearm_tweak.R.001", 'LIMITDIST_INSIDE')
    limit_bone_distance("forearm_tweak.R.001", "forearm_tweak.R", 'LIMITDIST_INSIDE')
    limit_bone_distance("forearm_tweak.R", "upper_arm_tweak.R.001", 'LIMITDIST_INSIDE')
    limit_bone_distance("upper_arm_tweak.R.001", "upper_arm_tweak.R", 'LIMITDIST_INSIDE')
    #
    copy_loc("hip_control", "torso")
    obj_driver("hip_control", 'rotation_euler', 2, "torso", 'ROT_Z', 'var * 1.5')
    #
    bpy.ops.object.posemode_toggle()
    bone_damp_trac("shoulder.L", "upper_arm_ik.L", 'TRACK_Y')
    bone_damp_trac("shoulder.R", "upper_arm_ik.R", 'TRACK_Y')
    cr("head", "head_control", 1)
    cr("neck", "head_control", 0.5)
    cr("chest", "chest_control", 1)
    cr("hips", "hip_control", 1)
    cr("foot_heel_ik.L", "foot_ik.L", 1)
    pb["foot_heel_ik.L"].constraints["Copy Rotation"].target_space = 'LOCAL'
    cr("foot_heel_ik.R", "foot_ik.R", 1)
    pb["foot_heel_ik.R"].constraints["Copy Rotation"].target_space = 'LOCAL'
    obj_limit_rot("head_control", [45, 145, -45, 45, -80, 80], 'LOCAL')
    obj_limit_rot("hip_control", [-45, 45, -15, 15, -45, 45], 'WORLD')
    obj_limit_rot("chest_control", [-60, 60, -25, 25, -35, 35], 'WORLD')
    obj_limit_rot("foot_ik.L", [-15, 30, -25, 15, -25, 25], 'WORLD')
    obj_limit_rot("foot_ik.R", [-15, 30, -15, 25, -25, 25], 'WORLD')
    bone_limit_rot("shoulder.L", [-10, 10, 0, 0, -90, -45], 'POSE')
    bone_limit_rot("shoulder.R", [-10, 10, 0, 0, 45, 90], 'POSE')
    bone_driver("foot_heel_ik.L", 'rotation_euler', 0, "foot_ik.L", 'ROT_X')
    bone_driver("foot_heel_ik.L", 'rotation_euler', 0, "foot_ik.L", 'ROT_X')
    bone_driver("thigh_ik.L", 'rotation_euler', 2, "foot_ik.L", 'ROT_Z')
    bone_driver("thigh_ik.R", 'rotation_euler', 2, "foot_ik.R", 'ROT_Z')
    for rb in pkrig:
        ct(rb)
    ctb("upper_arm_ik.L", 1)
    ctb("upper_arm_ik.R", 1)
    ctb("thigh_ik.L", 1)
    ctb("thigh_ik.R", 1)
    copy_transform('shoulder_socket.L', 'rig', 'upper_arm_ik.L', 0)
    copy_transform('shoulder_socket.R', 'rig', 'upper_arm_ik.R', 0)
    bpy.ops.object.posemode_toggle()
    bpy.data.objects["rig"].hide_viewport = True

@timeit
def MB_to_Rigify():
    import rigify
    align_rig()
    rigify.ui.generate.generate_rig(bpy.context, bpy.data.objects['metarig'])
    parent_rig()
