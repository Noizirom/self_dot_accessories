# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 3
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Self_Dot_Accessories",
    "author": "Noizirom",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Tools > Self_Dot_Accessories",
    "description": "Adds Accessories to Characters",
    "warning": "",
    "wiki_url": "",
    "category": "Characters",
}

import bpy
from bpy.types import Operator
from bpy.props import FloatVectorProperty
from bpy_extras.object_utils import AddObjectHelper, object_data_add
from mathutils import Vector
from . import MB_to_Rigify as MBR



class OBJECT_OT_Rigify(Operator, AddObjectHelper):
    """Create a Rigify Rig"""
    bl_idname = "acc.rigify"
    bl_label = "Add Rigify Rig"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        MBR.MB_to_Rigify()
        return {'FINISHED'}


class OBJECT_OT_PK_Rig(Operator, AddObjectHelper):
    """Create a Pino Kio Rig"""
    bl_idname = "acc.pk_rig"
    bl_label = "Add Pino Kio Rig"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        MBR.pino_kio_rig()
        return {'FINISHED'}


class VIEW3D_PT_Dot_Accessories(bpy.types.Panel):
    bl_label = "SELF_DOT_ACCESSORIES"
    bl_idname = "OBJECT_PT_accessories"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = 'objectmode'
    bl_category = "Self_Dot_Accessories"

    @classmethod
    def poll(cls, context):
        return context.mode in {'OBJECT', 'POSE'}

    def draw(self, context):
        self.layout.operator("acc.rigify", text="MB to Rigify")
        self.layout.operator("acc.pk_rig", text="Add Pino_Kio Rig")


# Registration



# This allows you to right click on a button and link to documentation
def add_object_manual_map():
    url_manual_prefix = "https://docs.blender.org/manual/en/latest/"
    url_manual_mapping = (
        ("bpy.ops.mesh.add_object", "scene_layout/object/types.html"),
    )
    return url_manual_prefix, url_manual_mapping

classes = [
    OBJECT_OT_Rigify,
    OBJECT_OT_PK_Rig,
    VIEW3D_PT_Dot_Accessories,
]


def register():
    #bpy.utils.register_class(OBJECT_OT_Rigify)
    bpy.utils.register_manual_map(add_object_manual_map)
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    #bpy.utils.unregister_class(OBJECT_OT_Rigify)
    bpy.utils.unregister_manual_map(add_object_manual_map)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
